# Eryx
#### Final code project for 2016, and mayby all time.

Designed to use several advanced sujects includeing *Interface Injection*, and *Profile Loading*

