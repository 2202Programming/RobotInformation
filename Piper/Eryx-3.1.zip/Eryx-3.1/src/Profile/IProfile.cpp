/*
* IProfile.cpp
*
*  Created on: Jan 30, 2016
*      Author: lazar
*/

#include "IProfile.h"

IProfile::IProfile() {
	// TODO Auto-generated constructor stub

}

IProfile::~IProfile() {
	// TODO Auto-generated destructor stub
}

