/*
 * IDrive.h
 *
 *  Created on: Jan 30, 2016
 *      Author: Beast
 */

#ifndef SRC_IDRIVE_H_
#define SRC_IDRIVE_H_

class IDrive {
public:
	IDrive();
	virtual ~IDrive();
};

#endif /* SRC_IDRIVE_H_ */
