/*
 * IDrive.cpp
 *
 *  Created on: Jan 30, 2016
 *      Author: Beast
 */

#include <IDrive.h>

IDrive::IDrive() {
	// TODO Auto-generated constructor stub

}

IDrive::~IDrive() {
	// TODO Auto-generated destructor stub
}

