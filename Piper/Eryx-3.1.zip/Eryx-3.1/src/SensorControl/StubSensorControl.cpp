/*
 * ISensorControl.cpp
 *
 *  Created on: Feb 6, 2016
 *      Author: Beasty
 */

#include <SensorControl/StubSensorControl.h>

StubSensorControl::StubSensorControl() {
	// TODO Auto-generated constructor stub

}

StubSensorControl::~StubSensorControl() {
	// TODO Auto-generated destructor stub
}

