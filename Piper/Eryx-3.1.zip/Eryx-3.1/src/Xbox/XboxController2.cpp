#include <Xbox/XboxController2.h>
XboxController2::~XboxController2() {}
