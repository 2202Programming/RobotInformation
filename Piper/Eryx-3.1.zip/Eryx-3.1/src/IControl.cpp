/*
 * IControl.cpp
 *
 *  Created on: Feb 11, 2015
 *      Author: David
 */

#include "IControl.h"

//int IControl::AutonomousPeriodic(int autoReturn[]) {
//	return 1;
//}
