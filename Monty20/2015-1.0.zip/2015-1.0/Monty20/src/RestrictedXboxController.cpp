#include "RestrictedXboxController.h"
RestrictedXboxController::~RestrictedXboxController() {}

// Hi
